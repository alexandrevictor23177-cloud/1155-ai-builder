
export default async (req) => {
  const headers = {
    "Content-Type": "application/json"
  };

  if (req.method !== "POST") {
    return new Response(
      JSON.stringify({ error: "Método não permitido" }),
      { status: 405, headers }
    );
  }

  try {
    const key = process.env.GROQ_API_KEY;

    if (!key) {
      throw new Error("GROQ_API_KEY não configurada.");
    }

    const body = await req.json();
    const prompt = String(body.prompt || "").slice(0, 3000);

    if (!prompt.trim()) {
      return new Response(
        JSON.stringify({ error: "Pedido vazio." }),
        { status: 400, headers }
      );
    }

    const history = Array.isArray(body.history)
      ? body.history.slice(-10).map(item => ({
          role: item.role === "assistant" ? "assistant" : "user",
          content: String(item.content || "").slice(0, 3000)
        }))
      : [];

    const response = await fetch(
      "https://api.groq.com/openai/v1/chat/completions",
      {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "Authorization": `Bearer ${key}`
        },
        body: JSON.stringify({
          model: "qwen/qwen3.8-27b",
          messages: [
            {
              role: "system",
              content: `Você é o 1155 AI BUILDER.
Especialista em Roblox Luau.
Responda somente JSON válido neste formato:
{
  "reply": "Explicação",
  "actions": []
}
Por enquanto, use somente ações do tipo part.
Nunca retorne código executável.
Valide os pedidos e não invente tipos de ação.`
            },
            ...history,
            { role: "user", content: prompt }
          ],
          response_format: {
            type: "json_object"
          },
          max_completion_tokens: 1200
        })
      }
    );

    const result = await response.json();

    if (!response.ok) {
      console.error("Groq:", result);
      return new Response(
        JSON.stringify({ error: "Erro ao consultar o Groq." }),
        { status: 502, headers }
      );
    }

    const ai = JSON.parse(
      result.choices[0].message.content
    );

    const actions = Array.isArray(ai.actions)
      ? ai.actions.filter(a => a && a.type === "part").slice(0, 50)
      : [];

    return new Response(
      JSON.stringify({
        reply: String(ai.reply || "Pronto!"),
        actions
      }),
      { status: 200, headers }
    );

  } catch (error) {
    console.error(error);

    return new Response(
      JSON.stringify({
        error: "Não foi possível processar o pedido."
      }),
      { status: 500, headers }
    );
  }
};
